import socket

# 定义主机和端口
host = 'localhost'
port = 7777

# 创建一个套接字对象
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 绑定套接字到指定的主机和端口
server_socket.bind((host, port))

# 开始监听，最大连接数为1
server_socket.listen(1)
print(f"正在监听 {host}:{port} 端口...")

try:
    # 接受连接请求
    client_socket, client_address = server_socket.accept()
    print(f"接受来自 {client_address} 的连接")

    # 与客户端通信
    while True:
        # 接收客户端发送的数据
        data = client_socket.recv(1024)
        if not data:
            break  # 如果没有数据，跳出循环

        # 打印收到的数据
        print(f"收到数据: {data.decode('utf-8')}")

        # 发送响应给客户端
        response = "收到你的消息"
        client_socket.send(response.encode('utf-8'))

except KeyboardInterrupt:
    print("手动中断")

finally:
    # 关闭套接字
    server_socket.close()
    print("套接字已关闭")
